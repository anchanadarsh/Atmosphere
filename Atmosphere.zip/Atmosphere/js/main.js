// All custom codes with comment

$(".c-particle").click(function(){
    $(".c-particle").removeClass("make_particle_big");
    $(this).addClass("make_particle_big");
});
