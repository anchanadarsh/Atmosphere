Put all codes which should be on each file.
<br/>
Like Navigation, Fixed elements, Copyrights, etc.